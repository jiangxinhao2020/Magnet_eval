import torch

from .sinet import SINet_ResNet50
from .sinetv2 import SINETV2
from .magnet import MAGNet
from .CaraNet import caranet
from .UACANet import UACANet
from .sanet import sanet
from .PFNet import PFNet
from .PraNet_Res2Net import PraNet
from .basnet import BASNet
from .hardnet import HarDNet
from .f3net import F3Net

def sinet(in_h=352, in_w=352):
    model = SINet_ResNet50()
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)


def sinetv2(in_h=352, in_w=352):
    model = SINETV2()
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)

def magnet(in_h=352, in_w=352):
    model = MAGNet()
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)

def Caranet(in_h=352, in_w=352):
    model = caranet()
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)

def uacanet(in_h=352, in_w=352):
    model = UACANet()
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)

def Sanet(in_h=352, in_w=352):
    model = sanet()
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)

def pfnet(in_h=352, in_w=352):
    model = PFNet()
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)

def pranet(in_h=352, in_w=352):
    model = PraNet()
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)

def basnet(in_h=352, in_w=352):
    model = BASNet(3,1)
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)

def hardnet(in_h=352, in_w=352):
    model = HarDNet(3,1)
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)

def hardnet(in_h=352, in_w=352):
    model = HarDNet(3,1)
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)

def f3net(in_h=352, in_w=352):
    model = F3Net()
    data = torch.randn(1, 3, in_h, in_w)
    return dict(model=model, data=data)
